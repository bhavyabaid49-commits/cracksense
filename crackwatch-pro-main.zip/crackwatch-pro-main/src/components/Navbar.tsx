import { Link } from "@tanstack/react-router";
import { HardHat } from "lucide-react";

export function Navbar() {
  const linkCls =
    "text-sm font-medium text-slate-200 hover:text-[var(--color-accent)] transition-colors";
  const activeCls = "text-[var(--color-accent)]";

  return (
    <header className="bg-[var(--color-primary)] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-semibold text-lg">
          <HardHat className="w-6 h-6 text-[var(--color-accent)]" />
          <span>CrackScan</span>
        </Link>
        <nav className="flex items-center gap-6">
          <Link to="/" className={linkCls} activeProps={{ className: activeCls }} activeOptions={{ exact: true }}>
            Home
          </Link>
          <Link to="/upload" className={linkCls} activeProps={{ className: activeCls }}>
            Upload
          </Link>
          <Link to="/history" className={linkCls} activeProps={{ className: activeCls }}>
            History
          </Link>
          <Link to="/about" className={linkCls} activeProps={{ className: activeCls }}>
            About
          </Link>
        </nav>
      </div>
    </header>
  );
}
