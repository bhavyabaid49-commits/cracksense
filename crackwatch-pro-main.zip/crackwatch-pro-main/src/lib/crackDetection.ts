// Heuristic crack detection using canvas-based image analysis.
// Mimics OpenCV pipeline: grayscale -> blur -> adaptive threshold -> connected pixel analysis.
// Returns a processed image (red-highlighted cracks) and metrics.

export type CrackType = "None" | "Hairline" | "Surface" | "Structural";
export type Severity = "None" | "Low" | "Moderate" | "Severe";

export interface DetectionResult {
  crackDetected: boolean;
  crackType: CrackType;
  severity: Severity;
  strengthLoss: number;         // percentage
  crackAreaCm2: number;         // approximate cm² (assume 1px = 0.02cm)
  crackLengthCm: number;
  cement: number;               // kg
  sealant: number;              // liters
  rebar: number;                // units
  processedImage: string;       // data URL
}

const PX_TO_CM = 0.02; // calibration: 1px ~ 0.02cm (assume ~12cm field at 600px)

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export async function detectCrack(dataUrl: string): Promise<DetectionResult> {
  const img = await loadImage(dataUrl);

  // Resize to max 600px wide for analysis
  const maxW = 600;
  const scale = Math.min(1, maxW / img.width);
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, w, h);

  const src = ctx.getImageData(0, 0, w, h);
  const gray = new Uint8ClampedArray(w * h);

  // Grayscale
  for (let i = 0; i < w * h; i++) {
    const r = src.data[i * 4];
    const g = src.data[i * 4 + 1];
    const b = src.data[i * 4 + 2];
    gray[i] = (0.299 * r + 0.587 * g + 0.114 * b) | 0;
  }

  // Compute local mean (box blur 11x11) for adaptive threshold
  const radius = 5;
  const blurred = new Uint8ClampedArray(w * h);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let sum = 0;
      let count = 0;
      const y0 = Math.max(0, y - radius);
      const y1 = Math.min(h - 1, y + radius);
      const x0 = Math.max(0, x - radius);
      const x1 = Math.min(w - 1, x + radius);
      for (let yy = y0; yy <= y1; yy += 2) {
        for (let xx = x0; xx <= x1; xx += 2) {
          sum += gray[yy * w + xx];
          count++;
        }
      }
      blurred[y * w + x] = (sum / count) | 0;
    }
  }

  // Adaptive threshold: pixel is crack if significantly darker than local mean
  const mask = new Uint8Array(w * h);
  let crackPixels = 0;
  const offset = 18;
  for (let i = 0; i < w * h; i++) {
    if (gray[i] < blurred[i] - offset && gray[i] < 130) {
      mask[i] = 1;
      crackPixels++;
    }
  }

  // Compute overall darkness ratio to skip uniformly dark images
  const totalPixels = w * h;
  const crackRatio = crackPixels / totalPixels;

  // Bounding extent for length estimation
  let minX = w, minY = h, maxX = 0, maxY = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (mask[y * w + x]) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  const extent = crackPixels > 0
    ? Math.hypot(maxX - minX, maxY - minY)
    : 0;

  // Classify
  let crackDetected = crackRatio > 0.004;
  let crackType: CrackType = "None";
  let severity: Severity = "None";
  let strengthLoss = 0;

  if (crackDetected) {
    if (crackRatio < 0.015) {
      crackType = "Hairline";
      severity = "Low";
      strengthLoss = 5 + Math.min(5, crackRatio * 300);
    } else if (crackRatio < 0.05) {
      crackType = "Surface";
      severity = "Moderate";
      strengthLoss = 15 + Math.min(10, (crackRatio - 0.015) * 285);
    } else {
      crackType = "Structural";
      severity = "Severe";
      strengthLoss = 35 + Math.min(15, (crackRatio - 0.05) * 300);
    }
  }

  // Material estimation
  const crackAreaCm2 = crackPixels * PX_TO_CM * PX_TO_CM;
  const crackLengthCm = extent * PX_TO_CM;
  const cement = +(crackAreaCm2 * 0.05).toFixed(2);
  const sealant = +(crackAreaCm2 * 0.02).toFixed(2);
  const rebar = crackType === "Structural" ? Math.max(1, Math.ceil(crackLengthCm / 30)) : 0;

  // Build processed image: original + red overlay on crack pixels
  const overlay = ctx.getImageData(0, 0, w, h);
  for (let i = 0; i < w * h; i++) {
    if (mask[i]) {
      overlay.data[i * 4]     = 230;  // R
      overlay.data[i * 4 + 1] = 30;   // G
      overlay.data[i * 4 + 2] = 30;   // B
      overlay.data[i * 4 + 3] = 255;
    }
  }
  ctx.putImageData(overlay, 0, 0);
  const processedImage = canvas.toDataURL("image/jpeg", 0.85);

  return {
    crackDetected,
    crackType,
    severity,
    strengthLoss: +strengthLoss.toFixed(1),
    crackAreaCm2: +crackAreaCm2.toFixed(2),
    crackLengthCm: +crackLengthCm.toFixed(2),
    cement,
    sealant,
    rebar,
    processedImage,
  };
}

export function severityColor(s: Severity): string {
  switch (s) {
    case "Low": return "bg-emerald-500 text-white";
    case "Moderate": return "bg-amber-500 text-white";
    case "Severe": return "bg-red-600 text-white";
    default: return "bg-slate-400 text-white";
  }
}
