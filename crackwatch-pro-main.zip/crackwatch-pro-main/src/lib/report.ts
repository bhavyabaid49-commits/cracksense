import jsPDF from "jspdf";

export interface ReportData {
  id: string;
  imageName: string;
  createdAt: string;
  crackDetected: boolean;
  crackType: string;
  severity: string;
  strengthLoss: number;
  cement: number;
  sealant: number;
  rebar: number;
  crackAreaCm2: number;
  originalImage: string;
  processedImage: string;
}

export function generatePdfReport(data: ReportData) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const margin = 40;
  let y = margin;

  doc.setFillColor(30, 41, 82);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 70, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.text("Crack Detection Report", margin, 45);

  y = 100;
  doc.setTextColor(20, 20, 20);
  doc.setFontSize(10);
  doc.text(`Report ID: ${data.id}`, margin, y);
  doc.text(`Date: ${new Date(data.createdAt).toLocaleString()}`, margin, y + 14);
  doc.text(`File: ${data.imageName}`, margin, y + 28);

  y += 60;
  doc.setFontSize(14);
  doc.setTextColor(30, 41, 82);
  doc.text("Inspection Summary", margin, y);
  y += 20;

  doc.setFontSize(11);
  doc.setTextColor(20, 20, 20);
  const rows: [string, string][] = [
    ["Crack Detected", data.crackDetected ? "Yes" : "No"],
    ["Crack Type", data.crackType],
    ["Severity", data.severity],
    ["Strength Loss", `${data.strengthLoss}%`],
    ["Crack Area", `${data.crackAreaCm2} cm²`],
    ["Cement Required", `${data.cement} kg`],
    ["Sealant Required", `${data.sealant} liters`],
    ["Rebar Required", `${data.rebar} units`],
  ];
  rows.forEach(([k, v]) => {
    doc.setFont("helvetica", "bold");
    doc.text(k + ":", margin, y);
    doc.setFont("helvetica", "normal");
    doc.text(v, margin + 140, y);
    y += 18;
  });

  y += 10;
  doc.setFontSize(14);
  doc.setTextColor(30, 41, 82);
  doc.text("Images", margin, y);
  y += 12;

  try {
    const imgW = 240, imgH = 180;
    doc.addImage(data.originalImage, "JPEG", margin, y, imgW, imgH);
    doc.addImage(data.processedImage, "JPEG", margin + imgW + 20, y, imgW, imgH);
    doc.setFontSize(9);
    doc.setTextColor(80, 80, 80);
    doc.text("Original", margin, y + imgH + 14);
    doc.text("Detected (red highlights)", margin + imgW + 20, y + imgH + 14);
  } catch (e) {
    console.error("PDF image error", e);
  }

  doc.save(`crack-report-${data.id.slice(0, 8)}.pdf`);
}
