import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Cpu, Database, Image as ImageIcon, Code2 } from "lucide-react";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({ meta: [{ title: "About · CrackScan" }] }),
});

const team = [
  { name: "Civil Engineering Lead", role: "Structural assessment design" },
  { name: "ML Engineer", role: "Computer vision & detection" },
  { name: "Product Engineer", role: "Full-stack development" },
];

const tech = [
  { icon: Code2, label: "React + TypeScript" },
  { icon: ImageIcon, label: "Canvas Image Analysis" },
  { icon: Cpu, label: "Adaptive Thresholding" },
  { icon: Database, label: "Lovable Cloud (Postgres)" },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-[var(--color-primary)] mb-4">About CrackScan</h1>
        <p className="text-muted-foreground leading-relaxed mb-10">
          CrackScan helps civil engineers, building inspectors, and property owners
          quickly assess the structural health of concrete and masonry surfaces.
          Upload an image and the system identifies cracks, classifies their severity,
          estimates the loss of mechanical strength, and calculates the materials
          needed to perform repairs.
        </p>

        <section className="mb-10">
          <h2 className="text-xl font-semibold text-[var(--color-primary)] mb-4">Team</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {team.map((m) => (
              <div key={m.name} className="bg-card border border-border rounded-xl p-5">
                <div className="w-12 h-12 rounded-full bg-[var(--color-primary)] text-[var(--color-accent)] flex items-center justify-center font-bold text-lg mb-3">
                  {m.name.split(" ").map(w => w[0]).slice(0,2).join("")}
                </div>
                <div className="font-semibold">{m.name}</div>
                <div className="text-sm text-muted-foreground">{m.role}</div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-[var(--color-primary)] mb-4">Technologies Used</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {tech.map((t) => (
              <div key={t.label} className="bg-card border border-border rounded-xl p-4 flex flex-col items-center text-center gap-2">
                <t.icon className="w-8 h-8 text-[var(--color-accent)]" />
                <div className="text-sm font-medium">{t.label}</div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
