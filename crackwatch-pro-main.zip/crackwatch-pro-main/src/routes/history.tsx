import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { severityColor } from "@/lib/crackDetection";
import { Eye, Trash2, Loader2 } from "lucide-react";

export const Route = createFileRoute("/history")({
  component: HistoryPage,
  head: () => ({ meta: [{ title: "Inspection History · CrackScan" }] }),
});

function HistoryPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>("All");

  const load = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("inspections")
      .select("id,image_name,image_data,crack_type,severity,strength_loss,cement_required,sealant_required,rebar_required,created_at")
      .order("created_at", { ascending: false });
    setRows(data ?? []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const remove = async (id: string) => {
    if (!confirm("Delete this inspection?")) return;
    await supabase.from("inspections").delete().eq("id", id);
    load();
  };

  const filtered = filter === "All" ? rows : rows.filter((r) => r.severity === filter);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-[var(--color-primary)]">Inspection History</h1>
            <p className="text-muted-foreground text-sm">All past crack analyses.</p>
          </div>
          <div className="flex items-center gap-2">
            <label className="text-sm text-muted-foreground">Filter by severity:</label>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="border border-border rounded-md px-3 py-2 text-sm bg-card"
            >
              {["All", "None", "Low", "Moderate", "Severe"].map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-[var(--color-accent)]" /></div>
        ) : filtered.length === 0 ? (
          <div className="bg-card border border-border rounded-xl p-12 text-center">
            <p className="text-muted-foreground mb-4">No inspections yet.</p>
            <Link to="/upload" className="inline-block bg-[var(--color-accent)] text-white px-5 py-2 rounded-lg font-semibold">Upload your first image</Link>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="text-left px-4 py-3">Date</th>
                    <th className="text-left px-4 py-3">Image</th>
                    <th className="text-left px-4 py-3">Type</th>
                    <th className="text-left px-4 py-3">Severity</th>
                    <th className="text-left px-4 py-3">Strength Loss</th>
                    <th className="text-left px-4 py-3">Materials</th>
                    <th className="text-right px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map((r) => (
                    <tr key={r.id} className="hover:bg-secondary/50">
                      <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{new Date(r.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        <img src={r.image_data} alt="" className="w-14 h-14 object-cover rounded-md border border-border" />
                      </td>
                      <td className="px-4 py-3 font-medium">{r.crack_type}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${severityColor(r.severity)}`}>
                          {r.severity}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-semibold">{Number(r.strength_loss)}%</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {Number(r.cement_required)}kg · {Number(r.sealant_required)}L · {Number(r.rebar_required)} rebar
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <Link to="/result/$id" params={{ id: r.id }} className="inline-flex items-center gap-1 text-[var(--color-primary)] hover:text-[var(--color-accent)] mr-3">
                          <Eye className="w-4 h-4" />
                        </Link>
                        <button onClick={() => remove(r.id)} className="inline-flex items-center gap-1 text-red-600 hover:text-red-800">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
