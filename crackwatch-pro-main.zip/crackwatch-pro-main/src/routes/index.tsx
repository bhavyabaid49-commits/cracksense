import { createFileRoute, Link } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Upload, ScanLine, FileText, ShieldCheck, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "CrackScan — AI Crack Detection for Structures" },
      { name: "description", content: "Detect cracks in concrete and masonry, assess strength loss, and estimate repair materials using AI-powered image analysis." },
    ],
  }),
});

function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      {/* Hero */}
      <section className="bg-gradient-to-br from-[var(--color-primary)] to-[#1a2447] text-white">
        <div className="max-w-6xl mx-auto px-4 py-24 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-block px-3 py-1 rounded-full bg-[var(--color-accent)]/20 text-[var(--color-accent)] text-xs font-semibold tracking-wide uppercase mb-4">
              Structural Integrity AI
            </span>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-4">
              Detect cracks. Assess damage. Estimate repairs — instantly.
            </h1>
            <p className="text-slate-300 text-lg mb-8">
              Upload a photo of any concrete or masonry surface. CrackScan identifies cracks,
              classifies severity, and tells you exactly how much material you need to fix it.
            </p>
            <Link
              to="/upload"
              className="inline-flex items-center gap-2 bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
            >
              <Upload className="w-5 h-5" />
              Get Started
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="aspect-video rounded-xl bg-slate-800/50 border border-white/10 backdrop-blur p-8 flex items-center justify-center">
              <ShieldCheck className="w-32 h-32 text-[var(--color-accent)]" strokeWidth={1.2} />
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-[var(--color-primary)] mb-4">How it works</h2>
          <p className="text-center text-muted-foreground mb-12">Three steps from photo to repair plan.</p>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Upload, title: "1. Upload Image", desc: "Drag and drop a JPG or PNG of the crack you want analyzed." },
              { icon: ScanLine, title: "2. Analyze", desc: "Our model segments cracks, measures area, and classifies severity." },
              { icon: FileText, title: "3. Get Report", desc: "Receive type, strength loss %, and exact repair materials needed." },
            ].map((s, i) => (
              <div key={i} className="bg-card rounded-xl p-8 border border-border shadow-sm hover:shadow-md transition-shadow text-center">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[var(--color-primary)] mb-4">
                  <s.icon className="w-7 h-7 text-[var(--color-accent)]" />
                </div>
                <h3 className="font-semibold text-lg mb-2 text-[var(--color-primary)]">{s.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-[var(--color-primary)] text-slate-300 py-8 mt-auto">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm">
          © {new Date().getFullYear()} CrackScan · Civil Engineering AI Tools
        </div>
      </footer>
    </div>
  );
}
