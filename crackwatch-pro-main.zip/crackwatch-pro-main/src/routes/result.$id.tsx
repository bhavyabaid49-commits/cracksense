import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { severityColor } from "@/lib/crackDetection";
import { generatePdfReport } from "@/lib/report";
import { Download, RotateCcw, Loader2, CheckCircle2, XCircle } from "lucide-react";

export const Route = createFileRoute("/result/$id")({
  component: ResultPage,
  head: () => ({ meta: [{ title: "Inspection Result · CrackScan" }] }),
});

function ResultPage() {
  const { id } = useParams({ from: "/result/$id" });
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase
        .from("inspections")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (!error) setData(data);
      setLoading(false);
    })();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-[var(--color-accent)]" />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-xl mx-auto px-4 py-24 text-center">
          <h1 className="text-2xl font-bold mb-2">Inspection not found</h1>
          <Link to="/upload" className="text-[var(--color-accent)] underline">Upload a new image</Link>
        </div>
      </div>
    );
  }

  const downloadPdf = () => {
    generatePdfReport({
      id: data.id,
      imageName: data.image_name,
      createdAt: data.created_at,
      crackDetected: data.crack_detected,
      crackType: data.crack_type,
      severity: data.severity,
      strengthLoss: Number(data.strength_loss),
      cement: Number(data.cement_required),
      sealant: Number(data.sealant_required),
      rebar: Number(data.rebar_required),
      crackAreaCm2: Number(data.crack_area),
      originalImage: data.image_data,
      processedImage: data.processed_image_data ?? data.image_data,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
          <div>
            <h1 className="text-3xl font-bold text-[var(--color-primary)]">Inspection Report</h1>
            <p className="text-muted-foreground text-sm">{new Date(data.created_at).toLocaleString()} · {data.image_name}</p>
          </div>
          <div className="flex gap-3">
            <button onClick={downloadPdf} className="inline-flex items-center gap-2 bg-[var(--color-primary)] hover:bg-[var(--color-primary)]/90 text-white px-4 py-2 rounded-lg text-sm font-semibold">
              <Download className="w-4 h-4" /> Download Report
            </button>
            <Link to="/upload" className="inline-flex items-center gap-2 bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white px-4 py-2 rounded-lg text-sm font-semibold">
              <RotateCcw className="w-4 h-4" /> Analyze Another
            </Link>
          </div>
        </div>

        {/* Images */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <div className="px-4 py-2 bg-secondary text-xs font-semibold uppercase tracking-wide text-muted-foreground">Original</div>
            <img src={data.image_data} alt="Original" className="w-full max-h-[420px] object-contain bg-slate-50" />
          </div>
          <div className="bg-card rounded-xl border border-border overflow-hidden">
            <div className="px-4 py-2 bg-secondary text-xs font-semibold uppercase tracking-wide text-muted-foreground">Detected (cracks in red)</div>
            <img src={data.processed_image_data ?? data.image_data} alt="Processed" className="w-full max-h-[420px] object-contain bg-slate-50" />
          </div>
        </div>

        {/* Results */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card label="Crack Detected">
            <div className="flex items-center gap-2">
              {data.crack_detected ? (
                <><CheckCircle2 className="w-6 h-6 text-red-600" /><span className="text-xl font-bold">Yes</span></>
              ) : (
                <><XCircle className="w-6 h-6 text-emerald-600" /><span className="text-xl font-bold">No</span></>
              )}
            </div>
          </Card>
          <Card label="Crack Type">
            <div className="text-xl font-bold">{data.crack_type}</div>
          </Card>
          <Card label="Severity">
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${severityColor(data.severity)}`}>
              {data.severity}
            </span>
          </Card>
          <Card label="Strength Loss">
            <div className="text-2xl font-bold text-[var(--color-accent)]">{Number(data.strength_loss)}%</div>
            <div className="text-xs text-muted-foreground mt-1">estimated structural reduction</div>
          </Card>
          <Card label="Crack Area">
            <div className="text-2xl font-bold">{Number(data.crack_area)} <span className="text-base font-normal">cm²</span></div>
          </Card>
          <Card label="Repair Materials">
            <ul className="space-y-1 text-sm">
              <li className="flex justify-between"><span className="text-muted-foreground">Cement</span><span className="font-semibold">{Number(data.cement_required)} kg</span></li>
              <li className="flex justify-between"><span className="text-muted-foreground">Sealant</span><span className="font-semibold">{Number(data.sealant_required)} L</span></li>
              <li className="flex justify-between"><span className="text-muted-foreground">Rebar</span><span className="font-semibold">{Number(data.rebar_required)} units</span></li>
            </ul>
          </Card>
        </div>
      </main>
    </div>
  );
}

function Card({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="bg-card rounded-xl border border-border p-5">
      <div className="text-xs uppercase tracking-wide text-muted-foreground font-semibold mb-2">{label}</div>
      {children}
    </div>
  );
}
