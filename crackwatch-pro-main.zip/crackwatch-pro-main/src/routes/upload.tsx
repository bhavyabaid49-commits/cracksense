import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useCallback, useRef } from "react";
import { Navbar } from "@/components/Navbar";
import { detectCrack } from "@/lib/crackDetection";
import { supabase } from "@/integrations/supabase/client";
import { UploadCloud, Loader2, ImageIcon } from "lucide-react";

export const Route = createFileRoute("/upload")({
  component: UploadPage,
  head: () => ({ meta: [{ title: "Upload Image · CrackScan" }] }),
});

function UploadPage() {
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    setError(null);
    if (!["image/jpeg", "image/png", "image/jpg"].includes(f.type)) {
      setError("Only JPG and PNG files are supported.");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      setError("File must be under 10MB.");
      return;
    }
    setFile(f);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(f);
  }, []);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const analyze = async () => {
    if (!file || !preview) return;
    setAnalyzing(true);
    setError(null);
    try {
      const result = await detectCrack(preview);
      const { data, error: dbError } = await supabase
        .from("inspections")
        .insert({
          image_name: file.name,
          image_data: preview,
          processed_image_data: result.processedImage,
          crack_detected: result.crackDetected,
          crack_type: result.crackType,
          severity: result.severity,
          strength_loss: result.strengthLoss,
          cement_required: result.cement,
          sealant_required: result.sealant,
          rebar_required: result.rebar,
          crack_area: result.crackAreaCm2,
        })
        .select("id")
        .single();
      if (dbError) throw dbError;
      navigate({ to: "/result/$id", params: { id: data.id } });
    } catch (e: any) {
      console.error(e);
      setError(e.message ?? "Analysis failed.");
      setAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-[var(--color-primary)] mb-2">Upload Image</h1>
        <p className="text-muted-foreground mb-8">
          Upload a clear photo of the concrete or masonry surface you want to inspect.
        </p>

        {!preview ? (
          <div
            onClick={() => inputRef.current?.click()}
            onDrop={onDrop}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            className={`cursor-pointer border-2 border-dashed rounded-xl p-16 text-center transition-colors ${
              dragOver ? "border-[var(--color-accent)] bg-[var(--color-accent)]/5" : "border-border bg-card hover:border-[var(--color-accent)]/60"
            }`}
          >
            <UploadCloud className="w-16 h-16 mx-auto mb-4 text-[var(--color-primary)]" strokeWidth={1.2} />
            <p className="font-semibold text-lg mb-1">Drop your image here</p>
            <p className="text-muted-foreground text-sm">or click to browse · JPG or PNG · max 10MB</p>
            <input
              ref={inputRef}
              type="file"
              accept="image/jpeg,image/png"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
            />
          </div>
        ) : (
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <ImageIcon className="w-4 h-4" /> {file?.name}
            </div>
            <img src={preview} alt="Preview" className="w-full max-h-[480px] object-contain rounded-lg bg-slate-50" />
            <div className="flex gap-3 mt-6">
              <button
                onClick={analyze}
                disabled={analyzing}
                className="flex-1 inline-flex items-center justify-center gap-2 bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 disabled:opacity-60 text-white font-semibold px-6 py-3 rounded-lg transition-colors"
              >
                {analyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing…</> : "Analyze"}
              </button>
              <button
                onClick={() => { setFile(null); setPreview(null); }}
                disabled={analyzing}
                className="px-6 py-3 rounded-lg border border-border hover:bg-secondary font-medium"
              >
                Change
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-4 p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
            {error}
          </div>
        )}
      </main>
    </div>
  );
}
