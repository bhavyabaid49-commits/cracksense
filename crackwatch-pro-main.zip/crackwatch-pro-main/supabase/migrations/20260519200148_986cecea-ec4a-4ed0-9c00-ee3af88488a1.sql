
CREATE TABLE public.inspections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_name TEXT NOT NULL,
  image_data TEXT NOT NULL,
  processed_image_data TEXT,
  crack_detected BOOLEAN NOT NULL DEFAULT false,
  crack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  strength_loss NUMERIC NOT NULL DEFAULT 0,
  cement_required NUMERIC NOT NULL DEFAULT 0,
  sealant_required NUMERIC NOT NULL DEFAULT 0,
  rebar_required NUMERIC NOT NULL DEFAULT 0,
  crack_area NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view inspections" ON public.inspections FOR SELECT USING (true);
CREATE POLICY "Anyone can insert inspections" ON public.inspections FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can delete inspections" ON public.inspections FOR DELETE USING (true);

CREATE INDEX idx_inspections_created_at ON public.inspections(created_at DESC);
CREATE INDEX idx_inspections_severity ON public.inspections(severity);
